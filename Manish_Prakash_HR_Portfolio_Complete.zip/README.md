# Manish Prakash HR Portfolio — GitHub Ready Repo

This repository contains a modern, one-page **HR Portfolio Website** for **Manish Prakash Pankaj**.

## Folder Structure
```
Manish_Prakash_HR_Portfolio/
├── index.html
├── Manish_Prkash_HR_Resume.pdf
└── README.md
```

## Deployment
1. Create a new GitHub repository and upload all files.
2. Enable GitHub Pages (Settings → Pages → Source → main branch → root).
3. Your site will be live at:
   ```
   https://<your-username>.github.io/Manish_Prakash_HR_Portfolio/
   ```

## Credits
**Created by:** Manish Prakash  
**Email:** manishibarts26@gmail.com  
**Location:** Bokaro, Jharkhand  
**Role:** HR Executive — Recruitment | Employee Engagement | Payroll & Compliance
